import socket
import time
import threading

HOST = '127.0.0.1'
PORT = 65432

def connect_to_server():
    while True:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((HOST,PORT))
            print(f"Connected to {HOST}:{PORT}")
            return s
        
        except socket.error as e:
            print(f"Connect failed: {e}. Retrying in 5 seconds...")
            s.close()
            time.sleep(5)




try:
    pass
except KeyboardInterrupt:
    print("Program terminated")
except Exception as e:
    print(f"An error occured: {e}")
finally:
    print("Resources released and motor stopped.")
